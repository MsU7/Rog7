# Rog7 AI Web App

A simple mobile-friendly starter web app for GitHub.

## Files

- `index.html` — main webpage
- `style.css` — design and layout
- `script.js` — button interaction

## How to upload using Working Copy

1. Open Working Copy.
2. Open your `Rog7` repository.
3. Tap `+`.
4. Import these files.
5. Commit with message: `Add Rog7 web app`.
6. Push to GitHub.

## How to view

Open `index.html` in a browser or host it using GitHub Pages.
