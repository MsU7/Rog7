const startBtn = document.getElementById("startBtn");
const message = document.getElementById("message");

startBtn.addEventListener("click", () => {
  const now = new Date().toLocaleString();
  message.textContent = `Demo started successfully at ${now}. Your Rog7 web app is working.`;
});
